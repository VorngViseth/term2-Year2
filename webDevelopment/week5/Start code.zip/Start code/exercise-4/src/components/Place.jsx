export default function Place() {
  return (
    <li key="the place id" className="place-item">
      <button>
        <img src="the place image src" alt="the place image alt" />
        <h3>"the place title"</h3>
      </button>
    </li>
  );
}
